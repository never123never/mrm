import  os, sys , time
os.system("clear")
time.sleep(2)
print("\033[31m\n          █████▒    ▒█████     ▒██   ██▒\n        ▓██   ▒    ▒██▒  ██▒   ▒▒ █ █▒░\n        ▒████ ░   ▒██░    ██▒    ░░█░\n        ░▓█▒  ░    ▒██   ██░    ░ █ █▒\n        ░▒█░       ░ ████▓▒░   ▒██▒▒██▒\n         ▒ ░       ░ ▒░▒░▒░    ▒▒ ░ ░▓ ░\n         ░           ░ ▒ ▒░    ░░   ░▒ ░\n         ░           ░ ░ ▒      ░    ░\n                       ░ ░      ░    ░\n\033[90;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n \033[0;1m     Auther: Zed\n      My lion: 💔\n      Chenal Telegram: kak_zed_1\n      Note: 10$ \n      Note: ID Active a DllaKam \n\033[90;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
while True:
	h = "fox"
	j = "zed"
	jj = input("  Username: ")
	hh = input("  Passowrd: ")
	if h == hh and j == jj :
		print("\033[32m Afarin \033[0;1m:)")
		print(50*"-")
		time.sleep(1)
		os.system("python2 .0.py")
	else:
		print("\033[33;1mHallaya !!")
		time.sleep(1)
		os.system("clear")
		print("\033[31m\n          █████▒    ▒█████     ▒██   ██▒\n        ▓██   ▒    ▒██▒  ██▒   ▒▒ █ █▒░\n        ▒████ ░   ▒██░    ██▒    ░░█░\n        ░▓█▒  ░    ▒██   ██░    ░ █ █▒\n        ░▒█░       ░ ████▓▒░   ▒██▒▒██▒\n         ▒ ░       ░ ▒░▒░▒░    ▒▒ ░ ░▓ ░\n         ░           ░ ▒ ▒░    ░░   ░▒ ░\n         ░           ░ ░ ▒      ░    ░\n                       ░ ░      ░    ░\n\033[90;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n \033[0;1m     Auther: Zed\n      My lion: 💔\n      Chenal Telegram: kak_zed_1\n      Note: 10$\n      Note: ID Active a DllaKam \n\033[90;1m~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
